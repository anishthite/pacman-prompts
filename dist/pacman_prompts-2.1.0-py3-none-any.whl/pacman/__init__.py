from pacman.pacman import *
from pacman.prompt import *
